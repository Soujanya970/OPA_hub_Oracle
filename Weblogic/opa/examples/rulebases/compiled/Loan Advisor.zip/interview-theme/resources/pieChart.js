    var svgns = "http://www.w3.org/2000/svg";
    var chartSize = 280;
    var size = 260;
    var pieOffset = 0;

    function addWedge(color) {
        var path = document.createElementNS(svgns, "path");
        path.setAttribute("fill", color);
        return path;
    }

    function updateWedge(path, startangle, endangle) {
        var scale = 0.5;
        var x1 = (chartSize / 2) + (size * scale) * Math.sin(startangle);
        var y1 = (chartSize / 2 + pieOffset) - (size * scale) * Math.cos(startangle);
        var x2 = (chartSize / 2) + (size * scale) * Math.sin(endangle);
        var y2 = (chartSize / 2 + pieOffset) - (size * scale) * Math.cos(endangle);
        var big = 0;
        if (endangle - startangle > Math.PI) {
            big = 1;
        }
        var d = "M " + (chartSize / 2) + "," + (chartSize / 2 + pieOffset) +  // Start at circle center
            " L " + x1 + "," + y1 +     // Draw line to (x1,y1)
            " A " + (size * scale) + "," + (size * scale) +       // Draw an arc of radius r
            " 0 " + big + " 1 " +       // Arc details...
            x2 + "," + y2 +             // Arc goes to to (x2,y2)
            " Z";                       // Close path back to (cx,cy)
        path.setAttribute("d", d); // Set this path
    }

    function addCenteredText(options) {
        var text = document.createElementNS(svgns, "text");
        text.setAttribute("fill", options.color);
        text.textContent = options.text;
        text.style.fontFamily = "Verdana";
        text.style.fontWeight = options.fontWeight;
        text.style.fontSize = options.fontSize;
        text.setAttribute("text-anchor", "middle");

        return text;
    }

    function formatCurrency(v) {
        if (v == null)
            return "";
        var formattedValue = v.toFixed(2);
        var dotidx = formattedValue.indexOf(".");
        if (dotidx < 0) {
            dotidx = formattedValue.length;
        }

        while (dotidx > 3) {
            dotidx -= 3;
            formattedValue = formattedValue.substring(0, dotidx) + "," + formattedValue.substring(dotidx);
        }

        return "$" + formattedValue;
    }

    function addWedgeLabel(label, weight) {
        var captionText = addCenteredText({
            text: label,
            x: 0,
            y: 0,
            color: "white",
            fontSize: "12px",
            fontWeight: weight
        });

        return {
            caption: captionText
        }
    }

    function updateWedgeLabel(label, angle, dy, text) {
        var x1 = (chartSize / 2) + (size * 0.3) * Math.sin(angle);
        var y1 = (chartSize / 2 + pieOffset) - (size * 0.3) * Math.cos(angle);

        y1 += Math.cos(angle) * 20;

        label.caption.setAttribute("x", x1);
        label.caption.setAttribute("y", y1 - 5 + dy);
        if (text != null) {
            label.caption.textContent = text;
        }
    }

    OraclePolicyAutomation.AddExtension({
        customContainer: function(control) {
            var wedge1, wedge2;
            var wedge1Label, wedge2Label, wedge1vLabel, wedge2vLabel;

            if (control.getProperty("type") === "pie")
                return {
                    mount: function(el) {
                        var boxWidth = 280;
                        var boxHeight = 280;

                        var svg = document.createElementNS(svgns, "svg");
                        svg.setAttribute ( "viewBox", "0 0 " + boxWidth + " " + boxHeight);
                        svg.setAttribute ("width", boxWidth);
                        svg.setAttribute ( "height", boxHeight);
                        svg.style.display = "block";

                        el.appendChild(svg)

                        wedge1 = addWedge("rgb(255, 119, 0)");
                        wedge2 = addWedge("rgb(70, 87, 94)");

                        wedge1Label = addWedgeLabel("Principal", "bold")
                        wedge1vLabel = addWedgeLabel("$200", "normal")
                        wedge2Label = addWedgeLabel("Interest", "bold")
                        wedge2vLabel = addWedgeLabel("$300", "normal")

                        svg.appendChild(wedge1);
                        svg.appendChild(wedge2);

                        svg.appendChild(wedge1Label.caption);
                        svg.appendChild(wedge2Label.caption);
                        svg.appendChild(wedge1vLabel.caption);
                        svg.appendChild(wedge2vLabel.caption);
                    },
                    update: function(el) {
                        var controls = control.getControls();
                        var v1 = controls[0].getValue();
                        var v2 = controls[1].getValue();
                        var sum = v1 + v2;
                        var a = v1 / sum * Math.PI * 2;

                        updateWedge(wedge1, 0, a);
                        updateWedge(wedge2, a, Math.PI * 2);

                        updateWedgeLabel(wedge1Label, a / 2, -7)
                        updateWedgeLabel(wedge2Label, a / 2 + Math.PI, -7)
                        updateWedgeLabel(wedge1vLabel, a / 2, 7, formatCurrency(v1))
                        updateWedgeLabel(wedge2vLabel, a / 2 + Math.PI, 7, formatCurrency(v2))
                    }
                }
        }
    })